package Atividade;

public class Universidade {
    private String nome;
    public Universidade(String nome){
        this.nome=nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public static void main(String[] args) {
        Universidade universidade = new Universidade("Universidade Integrado");
        System.out.println("Nome da universidade: "+ universidade.getNome());
    }
}
