package Atividade;

public class Pessoa {
    private String nome;
    private int nascimento;
    private Universidade universiade;


    public Pessoa(String nome, int  nascimento, Universidade universidade){
        this.nome=nome;
        this.nascimento=nascimento;
        this.universiade=universidade;

    }

    public String getNome() {
        return nome;
    }

    public Universidade getUniversiade() {
        return universiade;
    }

    public void setUniversiade(Universidade universiade) {
        this.universiade = universiade;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNascimento() {
        return nascimento;
    }

    public void setNascimento(int nascimento) {
        this.nascimento = nascimento;
    }

    public void infos(){
        System.out.println("Nome: "+nome);
    }

    public static void main(String[] args) {
        System.out.println(nome);
    }







}
