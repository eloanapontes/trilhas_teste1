## Desafio

Criar mais 7 classes utilizando o conceito de abstração.
Fazendo relacionamento entre estas classes.